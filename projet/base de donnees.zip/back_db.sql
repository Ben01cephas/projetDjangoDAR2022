-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 16 mars 2022 à 17:18
-- Version du serveur : 10.4.21-MariaDB
-- Version de PHP : 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `back_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add content type', 4, 'add_contenttype'),
(14, 'Can change content type', 4, 'change_contenttype'),
(15, 'Can delete content type', 4, 'delete_contenttype'),
(16, 'Can view content type', 4, 'view_contenttype'),
(17, 'Can add session', 5, 'add_session'),
(18, 'Can change session', 5, 'change_session'),
(19, 'Can delete session', 5, 'delete_session'),
(20, 'Can view session', 5, 'view_session'),
(21, 'Can add user', 6, 'add_user'),
(22, 'Can change user', 6, 'change_user'),
(23, 'Can delete user', 6, 'delete_user'),
(24, 'Can view user', 6, 'view_user'),
(25, 'Can add epreuve', 7, 'add_epreuve'),
(26, 'Can change epreuve', 7, 'change_epreuve'),
(27, 'Can delete epreuve', 7, 'delete_epreuve'),
(28, 'Can view epreuve', 7, 'view_epreuve'),
(29, 'Can add filliere', 8, 'add_filliere'),
(30, 'Can change filliere', 8, 'change_filliere'),
(31, 'Can delete filliere', 8, 'delete_filliere'),
(32, 'Can view filliere', 8, 'view_filliere'),
(33, 'Can add professeur', 9, 'add_professeur'),
(34, 'Can change professeur', 9, 'change_professeur'),
(35, 'Can delete professeur', 9, 'delete_professeur'),
(36, 'Can view professeur', 9, 'view_professeur'),
(37, 'Can add test', 10, 'add_test'),
(38, 'Can change test', 10, 'change_test'),
(39, 'Can delete test', 10, 'delete_test'),
(40, 'Can view test', 10, 'view_test');

-- --------------------------------------------------------

--
-- Structure de la table `back_epreuve`
--

CREATE TABLE `back_epreuve` (
  `id_epreuve` bigint(20) NOT NULL,
  `nom_fichier_epreuve` varchar(100) NOT NULL,
  `nom_fichier_correction` varchar(100) NOT NULL,
  `nom_epreuve` varchar(50) NOT NULL,
  `niveau_epreuve` varchar(50) NOT NULL,
  `annee_epreuve` int(11) NOT NULL,
  `matiere_epreuve` varchar(50) NOT NULL,
  `nom_prof` varchar(50) NOT NULL,
  `nom_filliere` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `back_epreuve`
--

INSERT INTO `back_epreuve` (`id_epreuve`, `nom_fichier_epreuve`, `nom_fichier_correction`, `nom_epreuve`, `niveau_epreuve`, `annee_epreuve`, `matiere_epreuve`, `nom_prof`, `nom_filliere`, `username`) VALUES
(9, 'files/epreuve/001.pdf', 'files/epreuve/002.pdf', 'Examen DJANGO 2020', 'LTI3-DAR', 2021, 'Developpement Web Avancé', 'KOUASSI', 'Informatique', 'cephas@gmail.com'),
(10, 'files/epreuve/Android_Cours_1.pdf', '', 'Examen Java', 'LTI3-DAR', 2020, 'Programmation Java', 'AKINOCHO', 'Informatique', 'abt@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `back_filliere`
--

CREATE TABLE `back_filliere` (
  `id_filliere` bigint(20) NOT NULL,
  `nom_filliere` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `back_filliere`
--

INSERT INTO `back_filliere` (`id_filliere`, `nom_filliere`) VALUES
(1, 'Informatique'),
(2, 'Developpement'),
(3, 'Management'),
(4, 'LTI3-DAR');

-- --------------------------------------------------------

--
-- Structure de la table `back_professeur`
--

CREATE TABLE `back_professeur` (
  `id_prof` bigint(20) NOT NULL,
  `nom_prof` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `back_professeur`
--

INSERT INTO `back_professeur` (`id_prof`, `nom_prof`) VALUES
(1, 'AKINOCHO'),
(2, 'PREIRA'),
(3, 'KOUASSI'),
(4, 'ONANA'),
(5, 'DER');

-- --------------------------------------------------------

--
-- Structure de la table `back_test`
--

CREATE TABLE `back_test` (
  `id` bigint(20) NOT NULL,
  `nom` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `back_user`
--

CREATE TABLE `back_user` (
  `id` bigint(20) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_fromEsmt` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `adresse` longtext NOT NULL,
  `first_name` longtext NOT NULL,
  `last_name` longtext NOT NULL,
  `telephone` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `back_user`
--

INSERT INTO `back_user` (`id`, `password`, `last_login`, `is_superuser`, `email`, `is_fromEsmt`, `is_staff`, `is_active`, `date_joined`, `adresse`, `first_name`, `last_name`, `telephone`) VALUES
(1, 'pbkdf2_sha256$320000$CS562eWu0RAitGszbITO9F$SX18qRRNd3q/h9u40SGc11m8/JwgdyWyiUiV9/1Ewgs=', '2022-03-16 16:15:16.726404', 1, 'admin@example.com', 0, 1, 1, '2022-03-02 14:16:10.348457', '1', '1', '1', '1'),
(2, 'pbkdf2_sha256$320000$ZfWdmVjHsQyBhgqes5OHWs$3MLBll3k3PRy509mMxq1T+ruKcEhs0r7DJat6dWF8ZQ=', '2022-03-02 16:57:07.414474', 0, 'mahoungoucephas@gmail.com', 1, 0, 1, '2022-03-02 14:17:23.423428', '1', '1', '1', '1'),
(3, 'pbkdf2_sha256$320000$KVqBKBIYV5AH53jzYpAOGt$k8P1n0H22H2ILe/4V/Kz39vciB3weYsDuJIYsEOJOcE=', NULL, 0, 'ben@gmail.com', 0, 0, 1, '2022-03-02 14:50:41.464189', '1', '1', '1', '1'),
(4, 'pbkdf2_sha256$320000$GL2yjUh0IALeAqlkQhp8mj$J+Dn6ao6w3Mxgwb3F+U6HWVgZEmVVNig17gNGtIBIQg=', NULL, 0, 'ben2@gmail.com', 1, 0, 1, '2022-03-02 14:52:04.194099', '1', '1', '1', '1'),
(5, 'pbkdf2_sha256$320000$U6yRb9ZBxXQngu2WQwIAnP$wVGFNCxPZlZU/XX3+vpn08qQzsjTTB1JxzRw0bM13YE=', '2022-03-13 12:27:22.193537', 0, 'ben@ben.com', 0, 0, 1, '2022-03-13 12:20:39.662515', '1', '1', '1', '1'),
(7, 'pbkdf2_sha256$320000$zNJVLYtFuD66CjyqqXlAw8$xDP5CJLrkZnBs9MjpuwkQ3QTKy29poVP9WIX4d8Blqs=', '2022-03-16 16:14:36.319983', 0, 'cephas@gmail.com', 1, 0, 1, '2022-03-13 13:20:14.552131', 'Dakar', 'Céphas', 'Mahoungou', '787173812736'),
(8, 'pbkdf2_sha256$320000$x63xK7VvGXJNMnFzC37c9y$2aCburbWHZNWL23zKd8TeUpZLiRoDxqA948UTbtLVv4=', '2022-03-13 15:11:01.019162', 0, 'abt@gmail.com', 1, 0, 1, '2022-03-13 14:31:18.963018', 'Medina', 'Aboubacar', 'TRAORE', '779239387'),
(9, 'pbkdf2_sha256$320000$t6sVNfSbOUTvsxCGGqDNex$5jy+MZg0tICX6QvfTaTm1jiZ5SFU5Wl8lUw68XDIido=', '2022-03-13 15:10:03.375089', 0, 'espoir@gmail.com', 0, 0, 1, '2022-03-13 15:09:35.478505', 'Colobane', 'Espoir', 'Norbert', '77665545');

-- --------------------------------------------------------

--
-- Structure de la table `back_user_groups`
--

CREATE TABLE `back_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `back_user_user_permissions`
--

CREATE TABLE `back_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2022-03-02 14:17:23.761105', '2', 'mahoungoucephas@gmail.com', 1, '[{\"added\": {}}]', 6, 1),
(2, '2022-03-02 15:31:21.583027', '1', 'Professeur object (1)', 1, '[{\"added\": {}}]', 9, 1),
(3, '2022-03-02 15:31:25.611522', '2', 'Professeur object (2)', 1, '[{\"added\": {}}]', 9, 1),
(4, '2022-03-02 15:31:31.467898', '3', 'Professeur object (3)', 1, '[{\"added\": {}}]', 9, 1),
(5, '2022-03-02 15:31:40.454407', '4', 'Professeur object (4)', 1, '[{\"added\": {}}]', 9, 1),
(6, '2022-03-02 15:31:46.658559', '5', 'Professeur object (5)', 1, '[{\"added\": {}}]', 9, 1),
(7, '2022-03-02 15:32:00.585401', '1', 'Filliere object (1)', 1, '[{\"added\": {}}]', 8, 1),
(8, '2022-03-02 15:32:08.549030', '2', 'Filliere object (2)', 1, '[{\"added\": {}}]', 8, 1),
(9, '2022-03-02 15:32:12.311862', '3', 'Filliere object (3)', 1, '[{\"added\": {}}]', 8, 1),
(10, '2022-03-02 15:32:18.251080', '4', 'Filliere object (4)', 1, '[{\"added\": {}}]', 8, 1),
(11, '2022-03-13 12:20:39.891024', '5', 'ben@ben.com', 1, '[{\"added\": {}}]', 6, 1);

-- --------------------------------------------------------

--
-- Structure de la table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(7, 'Back', 'epreuve'),
(8, 'Back', 'filliere'),
(9, 'Back', 'professeur'),
(10, 'back', 'test'),
(6, 'Back', 'user'),
(4, 'contenttypes', 'contenttype'),
(5, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Structure de la table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-03-02 14:15:24.787714'),
(2, 'contenttypes', '0002_remove_content_type_name', '2022-03-02 14:15:24.836070'),
(3, 'auth', '0001_initial', '2022-03-02 14:15:25.022986'),
(4, 'auth', '0002_alter_permission_name_max_length', '2022-03-02 14:15:25.103260'),
(5, 'auth', '0003_alter_user_email_max_length', '2022-03-02 14:15:25.112349'),
(6, 'auth', '0004_alter_user_username_opts', '2022-03-02 14:15:25.124283'),
(7, 'auth', '0005_alter_user_last_login_null', '2022-03-02 14:15:25.139245'),
(8, 'auth', '0006_require_contenttypes_0002', '2022-03-02 14:15:25.143233'),
(9, 'auth', '0007_alter_validators_add_error_messages', '2022-03-02 14:15:25.156198'),
(10, 'auth', '0008_alter_user_username_max_length', '2022-03-02 14:15:25.168167'),
(11, 'auth', '0009_alter_user_last_name_max_length', '2022-03-02 14:15:25.177141'),
(12, 'auth', '0010_alter_group_name_max_length', '2022-03-02 14:15:25.198768'),
(13, 'auth', '0011_update_proxy_permissions', '2022-03-02 14:15:25.208741'),
(14, 'auth', '0012_alter_user_first_name_max_length', '2022-03-02 14:15:25.221368'),
(15, 'back', '0001_initial', '2022-03-02 14:15:25.533958'),
(16, 'back', '0002_remove_user_is_newsletter', '2022-03-02 14:15:25.555638'),
(17, 'admin', '0001_initial', '2022-03-02 14:15:25.688699'),
(18, 'admin', '0002_logentry_remove_auto_add', '2022-03-02 14:15:25.702663'),
(19, 'admin', '0003_logentry_add_action_flag_choices', '2022-03-02 14:15:25.716625'),
(20, 'sessions', '0001_initial', '2022-03-02 14:15:25.760538'),
(21, 'back', '0003_epreuve_filliere_professeur', '2022-03-02 15:00:48.246764'),
(22, 'back', '0004_user_adresse_user_first_name_user_last_name_and_more', '2022-03-13 13:04:41.354616'),
(23, 'back', '0005_test_alter_epreuve_nom_fichier_correction_and_more', '2022-03-15 12:20:56.890863');

-- --------------------------------------------------------

--
-- Structure de la table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('i7fc3vxkcvto4zy5w8ryc305hsyv4wrm', '.eJxVjDkOwyAUBe9CHSEWs6VM7zMg-B-CkwgkY1dR7m5bcuG0b2bel_iwLsWvPc1-QnIngtyuWwzwTvUA-Ar12Si0usxTpIdCT9rp2DB9Hqf7d1BCL3sdrURQDsFobiXLSlgYpAOtkHMOyuiQs5DD7pkkUGeWWNaWuwiAERz5bdnQOBA:1nPSFN:WIoJOsHEDKU_M2FeNhSk1RDD3ibjewtor-kAZJZJPTs', '2022-03-16 16:54:41.278700'),
('z3bnbwt2mzegtdah2jeftxfpsmy1831h', '.eJxVjEEOwiAQRe_C2hAo4IhL9z0DmYFBqgaS0q6Md7dNutDtf-_9twi4LiWsnecwJXEVWpx-N8L45LqD9MB6bzK2uswTyV2RB-1ybIlft8P9OyjYy1Y7lTwBgSIwFAcg49kgRZvdAJn5zMzacwKNxllHFxOTs9EBbn5WXny-_x84mQ:1nUWIu:5Lg0uyMwFaVu-BEnEbMf1ZynF0586h1UlkQFnBgtG2s', '2022-03-30 16:15:16.732390');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Index pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Index pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Index pour la table `back_epreuve`
--
ALTER TABLE `back_epreuve`
  ADD PRIMARY KEY (`id_epreuve`);

--
-- Index pour la table `back_filliere`
--
ALTER TABLE `back_filliere`
  ADD PRIMARY KEY (`id_filliere`);

--
-- Index pour la table `back_professeur`
--
ALTER TABLE `back_professeur`
  ADD PRIMARY KEY (`id_prof`);

--
-- Index pour la table `back_test`
--
ALTER TABLE `back_test`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `back_user`
--
ALTER TABLE `back_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Index pour la table `back_user_groups`
--
ALTER TABLE `back_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Back_user_groups_user_id_group_id_e175a259_uniq` (`user_id`,`group_id`),
  ADD KEY `Back_user_groups_group_id_b5b154e9_fk_auth_group_id` (`group_id`);

--
-- Index pour la table `back_user_user_permissions`
--
ALTER TABLE `back_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Back_user_user_permissions_user_id_permission_id_3e5353fd_uniq` (`user_id`,`permission_id`),
  ADD KEY `Back_user_user_permi_permission_id_51676c10_fk_auth_perm` (`permission_id`);

--
-- Index pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_Back_user_id` (`user_id`);

--
-- Index pour la table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Index pour la table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT pour la table `back_epreuve`
--
ALTER TABLE `back_epreuve`
  MODIFY `id_epreuve` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `back_filliere`
--
ALTER TABLE `back_filliere`
  MODIFY `id_filliere` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `back_professeur`
--
ALTER TABLE `back_professeur`
  MODIFY `id_prof` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `back_test`
--
ALTER TABLE `back_test`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `back_user`
--
ALTER TABLE `back_user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `back_user_groups`
--
ALTER TABLE `back_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `back_user_user_permissions`
--
ALTER TABLE `back_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT pour la table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Contraintes pour la table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Contraintes pour la table `back_user_groups`
--
ALTER TABLE `back_user_groups`
  ADD CONSTRAINT `Back_user_groups_group_id_b5b154e9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `Back_user_groups_user_id_95da9fbc_fk_Back_user_id` FOREIGN KEY (`user_id`) REFERENCES `back_user` (`id`);

--
-- Contraintes pour la table `back_user_user_permissions`
--
ALTER TABLE `back_user_user_permissions`
  ADD CONSTRAINT `Back_user_user_permi_permission_id_51676c10_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `Back_user_user_permissions_user_id_ce5ec6ac_fk_Back_user_id` FOREIGN KEY (`user_id`) REFERENCES `back_user` (`id`);

--
-- Contraintes pour la table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_Back_user_id` FOREIGN KEY (`user_id`) REFERENCES `back_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
